# meta-ad-publish — Get Started

You unzipped this folder. Now open it in Claude Code, type `/meta-ad-publish`, and it walks you through publishing image or video ads to your Meta account.

This README covers everything you need before that first run.

---

## What this does

Publishes Facebook + Instagram ads via Meta's Marketing API — no clicking around in the Ads Manager.

You answer questions, the skill:
- Uploads your images or videos
- Builds the right structure (Meta's *Flexible Ad Format* — multiple images/videos × multiple texts × multiple headlines per ad, Meta picks the best combinations)
- Drafts ad copy from your landing page if you don't have any yet (or accepts what you've already written)
- Creates a new ad set if you need one (Cost Cap or ROAS, with sensible defaults), or publishes into one you already have
- Generates a Python publish script for the batch and runs it
- Activates and verifies all 3 levels (campaign + ad set + ads) — Meta's activation does NOT cascade, so this matters

You don't need to know the Meta API. You don't need to write any code. You just answer questions.

---

## Setup — one time

### 1. Open this folder in Claude Code

Open Claude Code on your computer, then either:
- **Drag this folder into the Claude Code window**, OR
- **Open Claude Code and type:** `cd /path/to/this/folder` (where you unzipped it)

### 2. Make the helper scripts runnable

In Claude Code's terminal (or your terminal):

```
chmod +x scripts/upload-images.sh scripts/upload-video.sh
```

### 3. Get your Meta access token

If you haven't yet, follow the **Meta API setup guide** to generate a token. It walks you through the Meta UI flow:

> https://theprompted.github.io/matandvics-funnel/meta-api-setup/

You'll end up with a long string starting with `EAC` or `EAA` — that's your token.

### 4. Save your token in a `.env` file

In this folder, create a file called exactly `.env` (with the leading dot). Paste your token in like this:

```
META_ACCESS_TOKEN=EAC...your-long-token-here...
```

There's a `.env.example` in this folder you can copy from. **Important:** the `.gitignore` already excludes `.env` so it won't get accidentally shared.

### 5. Run the skill

In Claude Code, type:

```
/meta-ad-publish
```

The skill takes it from there. The first run also asks you for your ad account ID, page ID, Pixel ID, and (optionally) Instagram User ID — it remembers them for next time.

---

## What the skill will ask you

In order, on a normal run:

1. **Image ad or video ad?**
2. **Where are your image/video files?** (folder path)
3. **Existing ad set, or create a new one?** — if new: Cost Cap, ROAS, or both? What cap? What ROAS floor?
4. **Landing page URL + which CTA button?** — Learn More, Shop Now, Sign Up, or Get Offer
5. **Image clusters** (only if you have more than 10 images — Meta caps each ad at 10)
6. **Have copy ready, or want me to draft from your LP?**
7. **Review the script** + run it
8. **Activate?** — yes activates and verifies; no leaves it paused for you to review in Ads Manager

Every step has a back-out option. Nothing goes live until you confirm.

---

## What's in this folder

```
.claude/skills/meta-ad-publish/    ← the skill itself (Claude Code reads this)
  SKILL.md                         ← the guided flow
  references/
    failures-and-fixes.md          ← 13 documented Meta API failure modes
    api-quick-reference.md         ← endpoints + payloads in one page

templates/
  publish-image.py                 ← image-ad template
  publish-video.py                 ← video-ad template
  verify-and-activate.py           ← post-publish verification

scripts/
  upload-images.sh                 ← image upload helper
  upload-video.sh                  ← video upload + thumbnail extraction
```

You don't have to look at any of these. The skill uses them. They're there if you ever want to peek under the hood.

---

## Where your batches go

Each time you run the skill, it creates a Python script under:

```
publish-runs/publish-<date>-<batch-name>.py
```

That script is **yours to keep**. You can re-run it later, edit it, or use it as a template for a similar batch. The skill never deletes them.

---

## Troubleshooting

| Error you see | What it usually means |
|---|---|
| "object doesn't exist" | Your token didn't load — check `.env` has `META_ACCESS_TOKEN=` and you're running from this folder |
| "Image/Video Mismatch" | The skill should never produce this; if it does, paste the error to Claude Code |
| Empty hash file after upload | One of your image filenames has unusual characters — try renaming |

For anything else, paste the full error to Claude Code. It'll either find a documented fix in `references/failures-and-fixes.md` or surface it cleanly.

---

## What the skill will NEVER do

- **Activate ads without asking.** Every ad starts PAUSED. Activation is always a separate, confirmed step.
- **Re-create your campaigns or ad sets without asking.** New ad sets only get created if you explicitly say "create new" in the flow.
- **Send your token anywhere except Meta.** The token stays in your `.env` file. Nothing leaves your computer except the API calls to Meta.

---

## Locked rules the skill follows

You don't need to remember these — the skill enforces them — but if you're curious why your ads come out the way they do:

- API version v25.0
- Flexible Ad Format (`creative_asset_groups_spec` on the AD call), never Dynamic Creative
- First image hash on the creative must equal the first image in the ad's asset groups
- ROAS ad sets reuse the Cost Cap creative ID (preserves Meta's learning across bid strategies)
- Hard limits per ad: 10 images / 10 videos, 5 primary texts, 5 headlines
- `instagram_user_id`, never `instagram_actor_id` — they're different
- `contextual_multi_ads: {enroll_status: "OPT_OUT"}` on every creative

Each rule exists because skipping it caused a real failure once. See `references/failures-and-fixes.md` for the stories.
